# tkinter-data-entry
Data entry form tutorial using Python and Tkinter. Source code for Youtube tutorial: https://youtu.be/vusUfPBsggw
